breakerMenu = menu.add_player_feature("α WorldBreaker Menu Ω", "parent", 0).id
breakerMenuMain = menu.add_feature("α WorldBreaker Menu Ω", "parent", 0).id

local Root = utils.get_appdata_path("PopstarDevs", "2Take1Menu")


local pedLocals = player.get_player_ped(player.player_id())
local req, opt, popt, Paths, data, kick_param, kick_param_data = {}, {}, {}, {}, {}, {}, {}
Paths.Root = utils.get_appdata_path("PopstarDevs", "2Take1Menu")
Paths.kickdata = Paths.Root  .. "\\scripts\\WB_cfg\\WB_Kicks.ini"
Paths.kickparam = Paths.Root .. "\\scripts\\WB_cfg\\WB_KickParam.ini"

guns = {
   "0x92A27487",
    "0x958A4A8F",
    "0xF9E6AA4B",
    "0x84BD7BFD",
    "0x8BB05FD7",
    "0x440E4788",
    "0x4E875F73",
    "0xF9DCBF2D",
    "0xD8DF3C3C",
    "0x99B507EA",
    "0xDD5DF8D9",
    "0xDFE37640",
    "0x678B81B1",
    "0x19044EE0",
    "0xCD274149",
    "0x94117305",
    "0x3813FC08",
    "0x1B06D571",
    "0xBFE256D4",
    "0x5EF9FEC4",
    "0x22D8FE39",
    "0x3656C8C1",
    "0x99AEEB3B",
    "0xBFD21232",
    "0x88374054",
    "0xD205520E",
    "0x83839C4",
    "0x47757124",
    "0xDC4DB296",
    "0xC1B3C3D1",
    "0xCB96392F",
    "0x97EA20B8",
    "0xAF3696A1",
    "0x2B5EF5EC",
    "0x917F6C8C",
	"0x13532244",
    "0x2BE6766B",
    "0x78A97CD0",
    "0xEFE7E2DF",
    "0xA3D4D34",
    "0xDB1AA450",
    "0xBD248B55",
    "0x476BF155",
    "0x1D073A89",
    "0x555AF99A",
    "0x7846A318",
    "0xE284C527",
    "0x9D61E50F",
    "0xA89CB99E",
    "0x3AABBBAA",
    "0xEF951FBB",
    "0x12E82D3D",
    "0xBFEFFF6D",
    "0x394F415C",
    "0x83BF0278",
    "0xFAD1F1C9",
    "0xAF113F99",
    "0xC0A3098D",
    "0x969C3D67",
    "0x7F229F94",
    "0x84D6FAFD",
    "0x624FE830",
    "0x9D07F764",
    "0x7FD62962",
    "0xDBBD7280",
    "0x61012683",
    "0x5FC3C11",
    "0xC472FE2",
    "0xA914799",
    "0xC734385A",
    "0x6A6C02E0",
    "0xB1CA77B1",
    "0xA284510B",
    "0x4DD2DC56",
    "0x42BF8A85",
    "0x7F7497E5",
    "0x6D544C99",
    "0x63AB0442",
    "0x781FE4A",
    "0xB62D1F67",
    "0x93E220BD",
    "0xA0973D5E",
    "0xFDBC8A50",
    "0x497FACC3",
    "0x24B17070",
    "0x2C3731D9",
    "0xAB564B93",
    "0x787F0BB",
    "0xBA45E8B8",
    "0x23C9F95C",
    "0x34A67B97",
    "0x60EC506",
    "0xFBAB5776",
    "0xBA536372"
  }

opt.opption = menu.add_feature("Alt Godmode/OTR","parent",breakerMenuMain).id

popt.opption = menu.add_player_feature("Crashes/Kicks","parent",breakerMenu).id
popt.loops = menu.add_player_feature("Malicious Loops","parent",breakerMenu).id
popt.trolls = menu.add_player_feature("All Trolls","parent",breakerMenu).id
popt.attach = menu.add_player_feature("Attachment Trolling","parent",breakerMenu).id


function dataload()
if not utils.file_exists(Paths.kickdata) then	return end
for line in io.lines(Paths.kickdata) do data[#data + 1] = line end
end
dataload()

function paramload()
if not utils.file_exists(Paths.kickparam) then	return end
for line in io.lines(Paths.kickparam) do
	kick_param_data[#kick_param_data + 1] = line
end
end
paramload()

function dupe_param()
for i =1, #kick_param_data do
	for y = 1, #kick_param_data do
		kick_param[y] = kick_param_data[i]
	end
end
end
dupe_param()

function build_params(argcnt)
local ParaMs = {}
for i = 1, argcnt do
	local y = math.random(1, #kick_param_data)
	ParaMs[i] = kick_param_data[y]
end
return ParaMs
end



req.ctrl = function(e, t)
    if entity.is_an_entity(e) then
	if not network.has_control_of_entity(e) then
	    network.request_control_of_entity(e)
	    t = t or 25
	    local time = utils.time_ms() + t
	    while entity.is_an_entity(e) and not network.has_control_of_entity(e) do
		system.wait(0)
		network.request_control_of_entity(e)
		if time < utils.time_ms() then
		    return false
		end
	    end
	end
	return network.has_control_of_entity(e)
    end
    return false
end

local function s_coords(i, p)
    req.ctrl(i)
    entity.set_entity_velocity(i, v3())
    entity.set_entity_coords_no_offset(i, p)
end

function clean(X)
	req.ctrl(X, 350)
	entity.set_entity_velocity(X, v3())
	s_coords(X, v3(8000, 8000, -1000))
	entity.delete_entity(X)
	system.wait(1)
	menu.notify("Cleanup has completed", "", 10, 2)
	return
end

function cleanPeds()
    local remove = ped.get_all_peds()
    for i = 1, #remove do
        local Y = remove[i]
        if not ped.is_ped_a_player(Y) then
            req.ctrl(Y, 250)
            entity.set_entity_velocity(Y, v3())
            s_coords(Y, v3(8000, 8000, -1000))
            entity.delete_entity(Y)
        end
    end
end

local function request_model(h, t)
	if not h then 
		return 
	end
	if not streaming.has_model_loaded(h) then
   		streaming.request_model(h)
    	local time = utils.time_ms() + t
    	while not streaming.has_model_loaded(h) and time > utils.time_ms() do
       		system.wait(5)
   		end
	end
	return streaming.has_model_loaded(h)
end


local function Cped(type, hash, coords, dir)
	request_model(hash, 300)
	local ped = ped.create_ped(type, hash, coords, dir, true, false)
	streaming.request_model(hash)
	return ped
end

menu.add_player_feature("Invalid World Object Crash", "action", popt.opption, function(playerfeat, pid)
	local pos = player.get_player_coords(pid)
	if true then 
		--menu.notify("You will be teleported near the player, look away ASAP", "IWO Crash", 10, 2)
		--entity.set_entity_coords_no_offset(pedLocals, v3(pos.x + 5, pos.y + 5, pos.z))
		---system.wait(5000)
		ped.clear_ped_tasks_immediately(player.get_player_ped(pid))
		local objs = object.create_world_object(gameplay.get_hash_key("h4_prop_bush_buddleia_low_01"), player.get_player_coords(pid), true, false)
		system.wait(0)
		menu.notify("Crash Sent, Do Not Look At The Player", "IWO Crash", 10, 2)

		system.wait(12000)
		clean(objs)
	end
end)


menu.add_player_feature("Invalid World Object Spam", "action", popt.opption, function(playerfeat, pid)
	local pos = player.get_player_coords(pid)
	if true then  
		--menu.notify("You will be teleported near the player, look away ASAP", "IWO Crash", 10, 2)
		--entity.set_entity_coords_no_offset(pedLocals, v3(pos.x + 5, pos.y + 5, pos.z))
		---system.wait(5000)
		ped.clear_ped_tasks_immediately(player.get_player_ped(pid))
		local obj = object.create_world_object(gameplay.get_hash_key("h4_prop_grass_wiregrass_01"), player.get_player_coords(pid), true, false)
		local obj0 = object.create_world_object(gameplay.get_hash_key("h4_prop_bush_seagrape_low_01"), player.get_player_coords(pid), true, false)
		local obj1 = object.create_world_object(gameplay.get_hash_key("h4_prop_bush_buddleia_low_01"), player.get_player_coords(pid), true, false)
		menu.notify("Crash Sent, Do Not Look At The Player", "IWO Spam", 10, 2)

		system.wait(12000)
		clean(obj)
		clean(obj0)
		clean(obj1)

	end
end)

menu.add_player_feature("Supple Slods", "action", popt.opption, function(val, pid)
	ped.clear_ped_tasks_immediately(player.get_player_ped(pid))
	streaming.request_model(gameplay.get_hash_key("slod_human"))
	local sh = ped.create_ped(4, gameplay.get_hash_key("slod_human"), player.get_player_coords(pid), 0, true, false)
	streaming.set_model_as_no_longer_needed(gameplay.get_hash_key("slod_human"))
	streaming.request_model(gameplay.get_hash_key("slod_small_quadped"))
	local ss = ped.create_ped(4, gameplay.get_hash_key("slod_small_quadped"), player.get_player_coords(pid), 0, true, false)
	streaming.set_model_as_no_longer_needed(gameplay.get_hash_key("slod_small_quadped"))
	streaming.request_model(gameplay.get_hash_key("slod_large_quadped"))
	local sl = ped.create_ped(4, gameplay.get_hash_key("slod_large_quadped"), player.get_player_coords(pid), 0, true, false)
	streaming.set_model_as_no_longer_needed(gameplay.get_hash_key("slod_large_quadped"))
	menu.notify("Slods are hunting, standby...", "Slod Crash", 10, 2)

	system.wait(15000)
	
	network.request_control_of_entity(sh)
	entity.delete_entity(sh)
	
	network.request_control_of_entity(ss)
	entity.delete_entity(ss)

	network.request_control_of_entity(sl)
	entity.delete_entity(sl)
	menu.notify("Slods are sleeping.", "Slod Crash", 10, 2)
end)

menu.add_player_feature("Ped Pool Fill Crash", "action", popt.opption, function(k,pid)
for i = 0 , 30 do 
	pos = player.get_player_coords(pid)
	npc = Cped(26, 0x92991B72,pos, 0)
	system.wait(0)
end
system.wait(1)
for i = 0 , 30 do 
	ppos = player.get_player_coords(pid)
	npc = Cped(26, 0x92991B72,ppos , 0)
	system.wait(0)
end
system.wait(1)
for i = 0 , 30 do 
	pppos = player.get_player_coords(pid)
	npc = Cped(26, 0x92991B72,pppos ,0)
	system.wait(0)
end
system.wait(1)
for i = 0 , 30 do 
	ppos = player.get_player_coords(pid)
	npc = Cped(26, 0x92991B72,ppos , 0)
	system.wait(0)
end
system.wait(1)
for i = 0 , 30 do 
	pppos = player.get_player_coords(pid)
	npc = Cped(26, 0x92991B72,pppos ,0)
	system.wait(0)
end
		 
system.wait(15000)
cleanPeds()
end)

function Osiris_kick(pid)
script.trigger_script_event(-2043109205, pid, {0, 0, 17302, 9822, 1999, 6777888, 111222}) script.trigger_script_event(-2043109205, pid, {0, 0, 2327, 0, 0, 0, -307, 27777}) script.trigger_script_event(-988842806, pid, {0, 0, 2327, 0, 0, 0, -307, 27777}) script.trigger_script_event(-2043109205, pid, {0, 0, 27983, 7601, 1020, 3209051, 111222}) script.trigger_script_event(-2043109205, pid, {0, 0, 1010, 0, 0, 0, -2653, 50555}) script.trigger_script_event(-988842806, pid, {0, 0, 1111, 0, 0, 0, -5621, 57766}) script.trigger_script_event(-988842806, pid, {0, 0, -3, -90, -123, -9856, -97652}) script.trigger_script_event(-2043109205, pid, {0, 0, -3, -90, -123, -9856, -97652}) script.trigger_script_event(-1881357102, pid, {0, 0, -3, -90, -123, -9856, -97652}) script.trigger_script_event(-988842806, pid, {0, 0, 20547, 1058, 1245, 2721936, 666333}) system.wait(25) script.trigger_script_event(-2043109205, pid, {0, 0, 20547, 1058, 1245, 2721936, 666333}) script.trigger_script_event(-1881357102, pid, {0, 0, 20547, 1058, 1245, 2721936, 666333}) script.trigger_script_event(153488394, pid, {0, 868904806, 0, 0, -152, -123, -978, 0, 0, 1, 0, -167, -144}) script.trigger_script_event(153488394, pid, {0, 868904806, 0, 0, 152, 123, 978, 0, 0, 1, 0, 167, 144}) script.trigger_script_event(1249026189, pid, {0, 0, 97587, 5697, 3211, 8237539, 967853}) script.trigger_script_event(1033875141, pid, {0, 0, 0, 1967}) script.trigger_script_event(1033875141, pid, {0, 0, -123, -957, -14, -1908, -123}) script.trigger_script_event(1033875141, pid, {0, 0, 12121, 9756, 7609, 1111111, 789666}) script.trigger_script_event(315658550, pid, {0, 0, 87111, 5782, 9999, 3333333, 888888}) script.trigger_script_event(-877212109, pid, {0, 0, 87111, 5782, 9999, 3333333, 888888}) script.trigger_script_event(1926582096, pid, {0, -1, -1, -1, 18899, 1011, 3070}) script.trigger_script_event(1926582096, pid, {0, -4640169, 0, 0, 0, -36565476, -53105203}) script.trigger_script_event(1033875141, pid, {-17645264, -26800537, -66094971, -45281983, -24450684, -13000488, 59643555, 34295654, 91870118, -3283691}) script.trigger_script_event(-988842806, pid, {0, 0, 93}) system.wait(25) script.trigger_script_event(-2043109205, pid, {0, 0, 37, 0, -7}) script.trigger_script_event(-1881357102, pid, {0, 0, -13, 0, 0, 0, 23}) script.trigger_script_event(153488394, pid, {0, 868904806, 0, 0, 7, 7, 19, 0, 0, 1, 0, -23, -27}) script.trigger_script_event(1249026189, pid, {}) script.trigger_script_event(315658550, pid, {}) script.trigger_script_event(-877212109, pid, {}) script.trigger_script_event(1033875141, pid, {0, 0, 0, 82}) script.trigger_script_event(1926582096, pid, {}) script.trigger_script_event(-977515445, pid, {26770, 95398, 98426, -24591, 47901, -64814}) script.trigger_script_event(-1949011582, pid, {pid, -1139568479, math.random(0, 4), math.random(0, 1)}) system.wait(25) script.trigger_script_event(-2043109205, pid, {0, 0, 3333, 0, 0, 0, -987, 21369}) script.trigger_script_event(-988842806, pid, {0, 0, 2222, 0, 0, 0, -109, 73322}) script.trigger_script_event(-977515445, pid, {26770, 95398, 98426, -24591, 47901, -64814}) script.trigger_script_event(-1949011582, pid,{pid, -1139568479, math.random(0, 4), math.random(0, 1)}) script.trigger_script_event(-1730227041, pid, {-494, 1526, 60541, -12988, -99097, -32105})end
function osiris_kick_v2(pid)
if network.network_is_host(player.player_id()) then
network.network_session_kick_player(pid)
end
end
function osiris_kick_v4(pid)
script.trigger_script_event(-720040631, pid, {}) script.trigger_script_event(1033875141, pid, {-17645264, -26800537, -66094971, -45281983, -24450684, -13000488, 59643555, 34295654, 91870118, -3283691}) script.trigger_script_event(-81613951, pid, {pid, script.get_global_i(1630317 + (1 + (pid * 595)) + 506)}) script.trigger_script_event(-1292453789, pid, {pid, script.get_global_i(1630317 + (1 + (pid * 595)) + 506)}) script.trigger_script_event(1623637790, pid, {pid, script.get_global_i(1630317 + (1 + (pid * 595)) + 506)}) script.trigger_script_event(-1905128202, pid, {pid, script.get_global_i(1630317 + (1 + (pid * 595)) + 506)}) script.trigger_script_event(1160415507, pid, {pid, script.get_global_i(1630317 + (1 + (pid * 595)) + 506)}) script.trigger_script_event(-2120750352, pid, {pid, script.get_global_i(1630317 + (1 + (pid * 595)) + 506)}) script.trigger_script_event(0xe6116600, pid, {pid, script.get_global_i(1630317 + (1 + (pid * 595)) + 506)}) system.wait(50) script.trigger_script_event(-922075519, pid, {pid, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, -1}) script.trigger_script_event(-1975590661, pid, {84857178, 61749268, -80053711, -78045655, 56341553, -78686524, -46044922, -22412109, 29388428, -56335450}) local pos = v3() pos = player.get_player_coords(pid) pos.x = math.floor(pos.x) pos.y = math.floor(pos.y) pos.z = math.floor(pos.z) script.trigger_script_event(-1975590661, pid, {pid, pos.x, pos.y, pos.z, 0, 0, 2147483647, 0, script.get_global_i(1590682 + (pid * 883) + 99 + 28), 1}) script.trigger_script_event(-1975590661, pid, {pid, pos.x, pos.y, pos.z, 0, 0, 1000, 0, script.get_global_i(1590682 + (pid * 883) + 99 + 28), 1}) script.trigger_script_event(-2122716210, pid, {91645, -99683, 1788, 60877, 55085, 72028}) script.trigger_script_event(-2120750352, pid, {pid, script.get_global_i(1630317 + (1 + (pid * 595)) + 506)}) script.trigger_script_event(-2122716210, pid, {91645, -99683, 1788, 60877, 55085, 72028}) script.trigger_script_event(0xE6116600, pid, {pid, script.get_global_i(1630317 + (1 + (pid * 595)) + 506)}) system.wait(50) script.trigger_script_event(0xB0886E20, pid, {0, 30583, 0, 0, 0, 1061578342, 1061578342, 4}) script.trigger_script_event(0xB0886E20, pid, {0, 30583, 0, 0, 0, 1061578342, 1061578342, 4}) script.trigger_script_event(0x9DB77399, pid, {50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 999999999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}) script.trigger_script_event(0x9DB77399, pid, {50, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 999999999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}) script.trigger_script_event(0xB0886E20, pid, {-1, 0, 0, 0}) script.trigger_script_event(0xB0886E20, pid, {0, -1, -1, 0}) script.trigger_script_event(0x9DB77399, pid, {-1, 0, -1, 0}) script.trigger_script_event(0xF5CB92DB, pid, {0, 0, 46190868, 0, 2}) script.trigger_script_event(0xF5CB92DB, pid, {46190868, 0, 46190868, 46190868, 2}) script.trigger_script_event(0xF5CB92DB, pid, {1337, -1, 1, 1, 0, 0, 0}) script.trigger_script_event(0xF5CB92DB, pid, {pid, 1337, -1, 1, 1, 0, 0, 0})
end

menu.add_player_feature("Osiris Kick", "action", popt.opption, function(feat, pid)
    Osiris_kick(pid)
end)

menu.add_player_feature("Revive Crash", "action", popt.opption, function(feat, pid)
    script.trigger_script_event(-2043109205, pid, {0, 0, 30583, 0, 0, 0, -328966, -1933210564, 0})
end)



menu.add_player_feature("Moist Kick v1", "action", popt.opption, function(feat, pid)

        script.trigger_script_event(0xc50f74ca, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
		script.trigger_script_event(2092565704, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
		script.trigger_script_event(2092565704, pid, {23135423, pid, 827870001, -1729222815, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})

end)

menu.add_player_feature("Moist Kick v2", "action", popt.opption, function(feat, pid)
    script.trigger_script_event(0x1d97a038, pid, {0, 0, 46190868, 0, 2})
    script.trigger_script_event(0x51ac3568, pid, {46190868, 0, 46190868, 46190868, 2})
    script.trigger_script_event(0x48276e68, pid, {1337, -1, 1, 1, 0, 0, 0})
    script.trigger_script_event(0x676680c7, pid, {pid, 1337, -1, 1, 1, 0, 0, 0})
    script.trigger_script_event(0x3935c307, pid, {-72614, 63007, 59027, -12012, -26996, 33399})
    script.trigger_script_event(0xb9102685, pid, {91645, -99683, 1788, 60877, 55085, 72028})
    script.trigger_script_event(2092565704, pid, {pid, script.get_global_i(1630816 + (1 + (pid * 597)) + 508)})
    script.trigger_script_event(0x7CBA04C8, pid, {pid, script.get_global_i(1630816 + (1 + (pid * 597)) + 508)})
    script.trigger_script_event(0x1ebe7832, pid, {-1, 500000, 849451549, -1, -1})
    script.trigger_script_event(0xdf8559f9, pid, {-1, 500000, 849451549, -1, -1})
    script.trigger_script_event(0x1cfa9df0, pid, {-1139568479, -1, 1, 100099})
    script.trigger_script_event(0xd8fae799, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 91645, -99683, 1788, 60877, 55085, 72028})
    script.trigger_script_event(0xb14e6c0c, pid, {-1, -1, -1, -1, -1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 91645, -99683, 1788, 60877, 55085, 72028})
    script.trigger_script_event(0xb939987b, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 91645, -99683, 1788, 60877, 55085, 72028})
end)

menu.add_player_feature("Modder Crash (M)", "action", popt.opption, function(feat, pid)

        script.trigger_script_event(0xc50f74ca, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
        script.trigger_script_event(0x9260c0a, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
        script.trigger_script_event(0x72d54f50, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
        script.trigger_script_event(0x8fdcc4d2, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
        script.trigger_script_event(0x72d54f50, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
        script.trigger_script_event(0xcbb6ce33, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
        script.trigger_script_event(0x3d9faec5, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
        script.trigger_script_event(0x4a72a08d, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
        script.trigger_script_event(0x8638a0ab, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
        script.trigger_script_event(0xc50f74ca, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
        script.trigger_script_event(0x12d09136, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})
        script.trigger_script_event(0x9260c0a, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
        script.trigger_script_event(0x72d54f50, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
        script.trigger_script_event(0x8fdcc4d2, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
        script.trigger_script_event(0x72d54f50, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
        script.trigger_script_event(0xcbb6ce33, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
        script.trigger_script_event(0x3d9faec5, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
        script.trigger_script_event(0x4a72a08d, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
        script.trigger_script_event(0x8638a0ab, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
        script.trigger_script_event(0xc50f74ca, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
        script.trigger_script_event(0x12d09136, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
        script.trigger_script_event(0xc50f74ca, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
        script.trigger_script_event(0x8638a0ab, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
        script.trigger_script_event(0xc50f74ca, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
        script.trigger_script_event(0x8638a0ab, pid, {pid, 0, 30583, 0, 0, 0, -328966, 1132039228, 0})
        script.trigger_script_event(0xc50f74ca, pid, {23135423, 3, 827870001, 2022580431, -918761645, 1754244778, 827870001, 1754244778, 23135423, 827870001, 23135423})

end)

menu.add_player_feature("Crash ScriptEvent Kick", "action", popt.opption, function(feat, pid)
        local SE_ARGS = build_params(20)
        script.trigger_script_event(0xcbb6ce33, pid, SE_ARGS)
        script.trigger_script_event(0x12d09136, pid, SE_ARGS)
        script.trigger_script_event(0xc50f74ca, pid, SE_ARGS)
        script.trigger_script_event(2092565704, pid, SE_ARGS)

end)

menu.add_player_feature("Script Host Crash Kick (M)", "action", popt.opption, function(feat, pid)
        local SE_ARGS = build_params(20)
			system.wait(800)
        script.trigger_script_event(0x8fdcc4d2, pid, SE_ARGS)
        script.trigger_script_event(0x72d54f50, pid, SE_ARGS)
        script.trigger_script_event(0xcbb6ce33, pid, SE_ARGS)
        script.trigger_script_event(0x12d09136, pid, SE_ARGS)

end)

menu.add_player_feature("Script Event Test", "action", popt.opption, function(feat, pid)
        script.trigger_script_event(1256866538, pid, {-1})
		system.yield(50)
        script.trigger_script_event(-1382676328, pid, {-1})
		system.yield(50)
        script.trigger_script_event(-1813981910, pid, {-1})

end)

menu.add_player_feature("SE Kick", "action", popt.opption, function(feat, pid)
	for i = 1, 2 do 
		script.trigger_script_event(1964309656, pid, {math.random(-2147483647, 2147483647)})
			system.yield(50)
		script.trigger_script_event(696123127, pid, {pid, math.random(-2147483647, 2147483647), pid})
			system.yield(50)
		script.trigger_script_event(43922647, pid, {pid, math.random(-2147483647, 2147483647)})
			system.yield(50)
		script.trigger_script_event(600486780, pid, {pid, -1, -1, -1, -1})
			system.yield(50)
		script.trigger_script_event(1954846099, pid, {math.random(-2147483647, -10)})
			system.yield(50)
		script.trigger_script_event(153488394, pid, {math.random(-2147483647, -10)})
			system.yield(50)
		for i, k in pairs({-1726396442, 154008137, 428882541, -1714354434}) do
			script.trigger_script_event(1463355688, pid, {pid, k, i, 1, math.random(-2147483647, -10) ,math.random(-2147483647, -10), math.random(-2147483647, -10), math.random(-2147483647, -10), math.random(-2147483647, -10), pid, math.random(-2147483647, -10), math.random(-2147483647, -10), math.random(-2147483647, -10)})
				system.yield(50)
		end
	end
	menu.notify("Script event kicks sent", "SE Kick", 10, 2)
end)

tbl_RemoteEvents={
	575344561,
	-588744584,
	59352546,
	600486780,
	608132931,
	-609583028,
	627052233,
	-639979452,
	649952111,
	-654645351,
	-662216118,
	677429013,
	690534430,
	701013663
}
menu.add_player_feature("SE Kick 2", "action", popt.opption, function(feat, pid)
	if feat.on then
		--player.unset_player_as_modder(pid, -1)
		for i = 1, #tbl_RemoteEvents do
			par1 = kick_param_data[math.random(1, #kick_param_data)]
			par2 = kick_param_data[math.random(1, #kick_param_data)]
			par3 = kick_param_data[math.random(1, #kick_param_data)]
			par4 = kick_param_data[math.random(1, #kick_param_data)]
			par5 = kick_param_data[math.random(1, #kick_param_data)]
			par6 = kick_param_data[math.random(1, #kick_param_data)]
				system.yield(50)
			script.trigger_script_event(tbl_RemoteEvents[i], pid, {par3, par5, par2, par3, par2, par1, par3, par1})
				system.yield(50)
			script.trigger_script_event(tbl_RemoteEvents[i], pid, {par1, par4, par3, par5, par6, par2, par3, par2, par1, par3, par1})
				system.yield(50)
		end
		menu.notify("Script event kicks sent", "SE Test", 10, 2)
	end
end)

menu.add_player_feature("ScriptHost Fuckarino (M)", "toggle", popt.opption, function(feat, pid)
if feat.on then
	if player.is_player_valid(pid) then
		script.trigger_script_event(-877212109, pid, {91645, -99683, 1788, 60877, 55085, 72028})
		script.trigger_script_event(-877212109, pid, {91645, -99683, 1788, 60877, 55085, 72028})
		script.trigger_script_event(0x7cba04c8, pid, {pid, script.get_global_i(1630816 + (1 + (7 * 597)) + 508)})
		script.trigger_script_event(-877212109, pid, {-1, 500000, 849451549, -1, -1})
		script.trigger_script_event(315658550, pid, {-1, 500000, 849451549, -1, -1})
		script.trigger_script_event(-877212109, pid, {-1139568479, -1, 1, 100099})
		script.trigger_script_event(315658550, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 91645, -99683, 1788, 60877, 55085, 72028})
		script.trigger_script_event(-877212109, pid, {-1, -1, -1, -1, -1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 91645, -99683, 1788, 60877, 55085, 72028})
		script.trigger_script_event(315658550, pid, {-1139568479, -1, 1, 100099, -1, 500000, 849451549, -1, -1, 91645, -99683, 1788, 60877, 55085, 72028})
		system.yield(350)
	end
			

end
end)

menu.add_player_feature("Kick Data 1 Type 1 (M)", "toggle", popt.opption, function(feat, pid)
	if feat.on then
		--player.unset_player_as_modder(pid, -1)
		for i = 1, #data do
			par1 = math.random(-1000, 99999999)
			par2 = math.random(-99999999999999, -9)
			par3 = math.random(46190868, 999999999)
			par4 = math.random(-1, 9)
			par5 = math.random(-99999999999999, -46190868)
			par6 = math.random(9999999999, 9999999899990868)
				system.yield(50)
			script.trigger_script_event(data[i], pid, {par3, par5, par2, par3, par2, par1, par3, par1})
				system.yield(50)
			script.trigger_script_event(data[i], pid, {par1, par4, par3, par5, par6, par2, par3, par2, par1, par3, par1})
				system.yield(50)
		end

	end
end)

menu.add_player_feature("Kick Data 1 Type 2 (M)", "toggle", popt.opption, function(feat, pid)
	if feat.on then
		for i = 1, #data do
			par1 = kick_param_data[math.random(1, #kick_param_data)]
			par2 = kick_param_data[math.random(1, #kick_param_data)]
			par3 = kick_param_data[math.random(1, #kick_param_data)]
			par4 = kick_param_data[math.random(1, #kick_param_data)]
			par5 = kick_param_data[math.random(1, #kick_param_data)]
			par6 = kick_param_data[math.random(1, #kick_param_data)]
				system.yield(150)
			script.trigger_script_event(data[i], pid, {par3, par5, par2, par3, par2, par1, par3, par1})
				system.yield(150)
			script.trigger_script_event(data[i], pid, {par5, par3, par1, par5, par3, par1, par5, par3, par1, par5, par3, par1, par5, par3, par1, par6, par3, par1, par5, par3, par1, par5, par3, par1, par5, par3, par1, par5, par3, par6, par5, par3, par1, par5, par3, par1, par5, par3, par1, par5, par3, par1, par5, par3, par1, par5, par3, par1, par5, par3, par1, par5, par3, par6})
				system.yield1(50)
			script.trigger_script_event(data[i], pid, {par1, par4, par3, par5, par6, par2, par3, par2, par1, par3, par1})
				system.yield(150)
		end
	end
end)

menu.add_player_feature("Rebuild SE Attack", "toggle", popt.opption, function(feat, pid)
	if feat.on then
		for i = 1, #data do
			par1 = kick_param_data[math.random(1, #kick_param_data)]
			par2 = kick_param_data[math.random(1, #kick_param_data)]
			par3 = kick_param_data[math.random(1, #kick_param_data)]
			par4 = kick_param_data[math.random(1, #kick_param_data)]
			par5 = kick_param_data[math.random(1, #kick_param_data)]
			par6 = kick_param_data[math.random(1, #kick_param_data)]
				system.yield(150)
			script.trigger_script_event(data[i], pid, {par3, par5, par2, par3, par2, par1, par3, par1})
				system.yield(150)
			script.trigger_script_event(data[i], pid, {par5, par3, par1, par5, par3, par1, par5, par3, par1, par5, par3, par1, par5, par3, par1, par6, par3, par1, par5, par3, par1, par5, par3, par1, par5, par3, par1, par5, par3, par6, par5, par3, par1, par5, par3, par1, par5, par3, par1, par5, par3, par1, par5, par3, par1, par5, par3, par1, par5, par3, par1, par5, par3, par6})
				system.yield(150)
			script.trigger_script_event(data[i], pid, {par1, par4, par3, par5, par6, par2, par3, par2, par1, par3, par1})
				system.yield(150)
			script.trigger_script_event(data[i], pid, {par3, par5, par2, par3, par2, par1, par3, par1})
				system.yield(150)
			script.trigger_script_event(data[i], pid, {par1, par4, par3, par5, par6, par2, par3, par2, par1, par3, par1})
				system.yield(150)
		end
	end
end)



menu.add_player_feature('Block - Passive', "action", popt.trolls, function(f, pid)
        script.trigger_script_event(1472357458, pid, {1, nil})
		script.trigger_script_event(1472357458, pid, {1, nil})
        menu.notify('Blocked Player from activating Passive.', 10, 2)
    end)

menu.add_player_feature('UN-Block - Passive', "action", popt.trolls, function(f, pid)
        script.trigger_script_event(1472357458, pid, {2, nil})
		script.trigger_script_event(1472357458, pid, {0, nil})
        menu.notify('UN-Blocked Player from Passive.', 10, 2)
    end)

menu.add_player_feature("Peaceful Player", "action", popt.trolls, function(playerfeat, pid)
	if true then 
		local pos = player.get_player_coords(pid)
		local playerPed = player.get_player_ped(pid)
		
		entity.set_entity_coords_no_offset(pedLocals, pos)
		ped.clear_ped_tasks_immediately(playerPed)
		
		for i = 1, #guns do
			local Y = guns[i]
			weapon.remove_weapon_from_ped(playerPed, Y)
			system.wait(1)
		end
		
		system.wait(1)
		
		ped.clear_ped_tasks_immediately(playerPed)
		network.request_control_of_entity(playerPed)
		ai.task_play_anim(playerPed, "switch@trevor@jerking_off", "trev_jerking_off_loop", 1.0, 1.0, 8000, 1, 1.0, false, true, true)
		--network.send_chat_message("I cum in peace", false)
	end
end)

menu.add_player_feature("He's Running", "action", popt.trolls, function(playerfeat, pid)
	if true then 
		local pos = player.get_player_coords(pid)
		local playerPed = player.get_player_ped(pid)
		local times = math.random(1, 20)
		
		entity.set_entity_coords_no_offset(pedLocals, pos)
		
		--network.send_chat_message("Gathering " .. times .. " eels for fun", false)
		system.wait(3000)
		--network.send_chat_message("Releasing the eels just for " .. player.get_player_name(pid), false)
		
		ped.clear_ped_tasks_immediately(playerPed)
		for i = 1, times do
			local pos = v3()
			pos = player.get_player_coords(pid)
			pos.z = pos.z + 65.0
			gameplay.shoot_single_bullet_between_coords(pos, player.get_player_coords(pid) + v3(0, 0, 1), 10000.00, 911657153, 0, true, false, 10000.0)
			system.wait(100)
		end
		
		system.wait(1)
	end
end)

menu.add_player_feature("Let me lift you up", "action", popt.trolls, function(val, pid)
	ped.clear_ped_tasks_immediately(player.get_player_ped(pid))
	system.wait(0)
	local pos = player.get_player_coords(pid)
    object.create_object(gameplay.get_hash_key("as_prop_as_target_scaffold_01a"), v3(pos.x, pos.y - .5, pos.z), true, false)
end)



menu.add_player_feature("Send Hit Squad", "action", popt.trolls, function(playerfeat, pid)
    local hash = gameplay.get_hash_key("s_m_y_xmech_02")
      
    streaming.request_model(hash)
    while (not streaming.has_model_loaded(hash)) do
        system.wait(0)
    end
      
    for i = 1, 10 do
        local pos = entity.get_entity_coords(player.get_player_ped(pid))
        pos.x = pos.x + math.random(-20, 20+i)
        pos.y = pos.y + math.random(-20, 20)

		local Peds = ped.create_ped(29, hash, pos, 1.0, true, false)
		weapon.give_delayed_weapon_to_ped(Peds, 0x476BF155, 0, true)
		ped.set_ped_health(Peds, 410)
		ped.set_ped_combat_ability(Peds, 2)
		ped.set_ped_combat_attributes(Peds, 5, true)
		ai.task_combat_ped(Peds, player.get_player_ped(pid), 1, 16)
		ped.set_ped_relationship_group_hash(Peds, 0x84DCFAAD)
		gameplay.shoot_single_bullet_between_coords(entity.get_entity_coords(Peds), entity.get_entity_coords(Peds) + v3(0, 0.0, 0.1), 0, 453432689, player.get_player_ped(pid), false, true, 100)
		streaming.set_model_as_no_longer_needed(hash)   
	end
end)


menu.add_player_feature("Player Lock on", "action", popt.trolls, function(feat, pid)
    streaming.request_model(0x15F8700D)
    local lock_on = ped.create_ped(2, 0x15F8700D, player.get_player_coords(pid), 0, false, false)
    entity.attach_entity_to_entity(lock_on, player.get_player_ped(pid), 0, v3(0, 0, 0), v3(0, 0, 0), true, false, false, 0, true)
end) 

Objs = {
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"10"
}

function seater(count, id)
	for u=1, count do
		local pos = player.get_player_coords(id)
		streaming.request_model(gameplay.get_hash_key("rcbandito"))
		cars[u] = vehicle.create_vehicle(gameplay.get_hash_key("rcbandito"), v3(pos.x + math.random(0, 15), pos.y + math.random(0, 15), pos.z), pos.z, true, false)
		streaming.request_model(0x92991B72)
		drivers[u] = ped.create_ped(26, 0x92991B72, v3(pos.x + 7, pos.y, pos.z), pos.z, true, false)
		ped.set_ped_into_vehicle(drivers[u], cars[u], -1)
		menu.notify("Bandito Spawned", "Stand", 10, 2)
		--vehicle.add_vehicle_phone_explosive_device(cars[u])
		ai.task_vehicle_chase(drivers[u], player.get_player_ped(id))
		ai.task_vehicle_follow(drivers[u], cars[u], player.get_player_ped(id), 50.0, 0, 1)
		menu.notify("Bandito Chasing", "Stand", 5, 2)
		system.wait(500)
	end
	return cars, drivers
end

menu.add_player_feature("Stand Lua", "action_value_str", popt.trolls, function(val, pid)
	local num = Objs[val.value+1]
	local boomed = 1
	cars = {}
	drivers = {}
	seater(num, pid)	
	while adding > 0 do
		for i = 1, #cars do
			system.wait(500)
			local pos1 = player.get_player_coords(pid)
			local poss = v3(pos1.x + 3, pos1.y + 3, pos1.z + 5)
			local bpos = entity.get_entity_coords(cars[i])
			--menu.notify("Bandito Hunting", "Stand", 10, 2)
			if (bpos.x <= poss.x) and (bpos.y <= poss.y) and (bpos.z <= poss.z)  or (bpos.x >= poss.x) and (bpos.y >= poss.y) and (bpos.z >= poss.z)then
				fire.add_explosion(bpos, 0, true, false, 2.0, player.get_player_ped(pid))
				--vehicle.detonate_vehicle_phone_explosive_device()
				menu.notify("Bandito Exploding", "Stand", 5, 2)
				--break
			end
			boomed = boomed + 1
			entity.delete_entity(drivers[i])
			entity.delete_entity(cars[i])
			--break
		end
		--break
	end
end):set_str_data(Objs)


menu.add_player_feature("Destroy Personal Vehicle Loop", "toggle", popt.loops, function(feat, pid)
        if feat.on then
            system.wait(2)
            script.trigger_script_event(-1662268941, pid, {-1, 0})
        end

    return HANDLER_CONTINUE
end)

menu.add_player_feature("Apartment Invite Loop", "toggle", popt.loops, function(feat, pid)
        if feat.on then
            system.wait(2)
            script.trigger_script_event(-171207973, pid, {-1, 0})
            script.trigger_script_event(1114696351, pid, {-1, 0})
            script.trigger_script_event(2027212960, pid, {-1, 0})
            script.trigger_script_event(0xf5cb92db, pid, {-1, 0})
            script.trigger_script_event(0x4270ea9f, pid, {-1, 0})
            script.trigger_script_event(0x78d4d0a0, pid, {-1, 0})
            script.trigger_script_event(0xf5cb92db, pid, {-171207973})
            script.trigger_script_event(0x4270ea9f, pid, {1114696351})
            script.trigger_script_event(0x78d4d0a0, pid, {2027212960})
        end

    return HANDLER_CONTINUE
end)

menu.add_player_feature("Vehicle EMP Loop", "toggle", popt.loops, function(feat, pid)
        if feat.on then
        system.wait(2)
            script.trigger_script_event(-152440739, pid, {-1, 0})
            script.trigger_script_event(-152440739, pid, {pid, -10000000, -10000000, -1000000, -10000000000, -100000, -1000000000, -10000, -10, -100, -1, -10000000000000, -10000000, -10000000, -1000000, -1000000, -100000, -1000000, -10, -10, pid, -10, pid})
        end
        return HANDLER_CONTINUE
        end)
		
menu.add_player_feature("Lag with Cargos", "toggle", popt.loops, function(feat, pid)            
	if feat.on then
		local pos = player.get_player_coords(pid)
		local veh_hash = 0x15F27762

streaming.request_model(veh_hash)
while (not streaming.has_model_loaded(veh_hash)) do
system.wait(10)
end

local tableOfVehicles = {}
for i = 1, 75 do
  tableOfVehicles[#tableOfVehicles + 1] = vehicle.create_vehicle(veh_hash, pos, pos.z, true, false)
end
system.wait(1000)
for i = 1, #tableOfVehicles do
  entity.delete_entity(tableOfVehicles[i])
end
tableOfVehicles = {}

streaming.set_model_as_no_longer_needed(veh_hash)



		end
	return HANDLER_CONTINUE
end)

menu.add_player_feature("Lag with Subs", "toggle", popt.loops, function(feat, pid)            
    if feat.on then
        local pos = player.get_player_coords(pid)
        local veh_hash = 0x4FAF0D70

streaming.request_model(veh_hash)
while (not streaming.has_model_loaded(veh_hash)) do
system.wait(10)
end


local tableOfVehicles = {}
for i = 1, 75 do
  tableOfVehicles[#tableOfVehicles + 1] = vehicle.create_vehicle(veh_hash, pos, pos.z, true, false)
end
system.wait(1000)
for i = 1, #tableOfVehicles do
  entity.delete_entity(tableOfVehicles[i])
end
tableOfVehicles = {}

streaming.set_model_as_no_longer_needed(veh_hash)


        end
    return HANDLER_CONTINUE
end)

menu.add_player_feature("Lag with invisible veh", "toggle", popt.loops, function(feat, pid)
	if feat.on then
		local pos = player.get_player_coords(pid)
		local veh_hash = 0x810369E2
		local veh_hash1 = 0x6827CF72
		local veh_hash2 = 0x4FAF0D70
		local veh_hash3 = 0xD039510B
		local veh_hash4 = 0x9B16A3B4
		local veh_hash5 = 0xC3FBA120
		local veh_hash6 = 0x1A7FCEFA
		local veh_hash7 = 0xCEEA3F4B
		local veh_hash8 = 0x2592B5CF
		local veh_hash9 = 0x81BD2ED0
		local veh_hash10 = 0x18606535
		local veh_hash11 = 0xF7004C86
		local veh_hash12 = 0x3D6AAA9B
		local veh_hash13 = 0xDB6B4924
		local veh_hash14 = 0xEDA4ED97
		local veh_hash15 = 0xFE0A508C
		local veh_hash16 = 0x15F27762
		local veh_hash17 =  0x3F119114
		local veh_hash18 = 0x250B0C5E
		local veh_hash19 = 0xB79F589E
		local veh_hash20 = 0x9D80F93
		local veh_hash21 = 0xB2CF7250
		local veh_hash22 = 0xB79C1BF5
		local veh_hash23 = 0x761E2AD3
		local veh_hash24 = 0x3E2E4F8A
		local veh_hash25 = 0x1AAD0DED
		local veh_hash26 = 0xEA313705
		local veh_hash27 = 0xE6E967F8
		local veh_hash28 = 0x4C80EB0E
		local veh_hash29 = 0xEDC6F847
		local veh_hash30 = 0xD577C962
		local veh_hash31 = 0x84718D34
		local veh_hash32 = 0x149BD32A
		local veh_hash33 = 0xB8081009
		local veh_hash34 = 0xA7FF33F5
		local veh_hash35 = 0x9E6B14D6
		local veh_hash36 = 0x6A59902D

streaming.request_model(veh_hash)
streaming.request_model(veh_hash1)
streaming.request_model(veh_hash2)
streaming.request_model(veh_hash3)
streaming.request_model(veh_hash4)
streaming.request_model(veh_hash5)
streaming.request_model(veh_hash6)
streaming.request_model(veh_hash7)
streaming.request_model(veh_hash8)
streaming.request_model(veh_hash9)
streaming.request_model(veh_hash10)
streaming.request_model(veh_hash11)
streaming.request_model(veh_hash12)
streaming.request_model(veh_hash13)
streaming.request_model(veh_hash14)
streaming.request_model(veh_hash15)
streaming.request_model(veh_hash16)
streaming.request_model(veh_hash17)
streaming.request_model(veh_hash18)
streaming.request_model(veh_hash19)
streaming.request_model(veh_hash20)
streaming.request_model(veh_hash21)
streaming.request_model(veh_hash22)
streaming.request_model(veh_hash23)
streaming.request_model(veh_hash24)
streaming.request_model(veh_hash25)
streaming.request_model(veh_hash26)
streaming.request_model(veh_hash27)
streaming.request_model(veh_hash28)
streaming.request_model(veh_hash29)
streaming.request_model(veh_hash30)
streaming.request_model(veh_hash31)
streaming.request_model(veh_hash32)
streaming.request_model(veh_hash33)
streaming.request_model(veh_hash34)
streaming.request_model(veh_hash35)
streaming.request_model(veh_hash36)

veh_spawn = vehicle.create_vehicle(veh_hash, pos, pos.z, true, false)
veh_spawn1 = vehicle.create_vehicle(veh_hash1, pos, pos.z, true, false)
veh_spawn2 = vehicle.create_vehicle(veh_hash2, pos, pos.z, true, false)
veh_spawn3 = vehicle.create_vehicle(veh_hash3, pos, pos.z, true, false)
veh_spawn4 = vehicle.create_vehicle(veh_hash4, pos, pos.z, true, false)
veh_spawn5 = vehicle.create_vehicle(veh_hash5, pos, pos.z, true, false)
veh_spawn6 = vehicle.create_vehicle(veh_hash6, pos, pos.z, true, false)
veh_spawn7 = vehicle.create_vehicle(veh_hash7, pos, pos.z, true, false)
veh_spawn8 = vehicle.create_vehicle(veh_hash8, pos, pos.z, true, false)
veh_spawn9 = vehicle.create_vehicle(veh_hash9, pos, pos.z, true, false)
veh_spawn10 = vehicle.create_vehicle(veh_hash10, pos, pos.z, true, false)
veh_spawn11 = vehicle.create_vehicle(veh_hash11, pos, pos.z, true, false)
veh_spawn12 = vehicle.create_vehicle(veh_hash12, pos, pos.z, true, false)
veh_spawn13 = vehicle.create_vehicle(veh_hash13, pos, pos.z, true, false)
veh_spawn14 = vehicle.create_vehicle(veh_hash14, pos, pos.z, true, false)
veh_spawn15 = vehicle.create_vehicle(veh_hash15, pos, pos.z, true, false)
veh_spawn16 = vehicle.create_vehicle(veh_hash16, pos, pos.z, true, false)
veh_spawn17 = vehicle.create_vehicle(veh_hash17, pos, pos.z, true, false)
veh_spawn18 = vehicle.create_vehicle(veh_hash18, pos, pos.z, true, false)
veh_spawn19 = vehicle.create_vehicle(veh_hash19, pos, pos.z, true, false)
veh_spawn20 = vehicle.create_vehicle(veh_hash20, pos, pos.z, true, false)
veh_spawn21 = vehicle.create_vehicle(veh_hash21, pos, pos.z, true, false)
veh_spawn22 = vehicle.create_vehicle(veh_hash22, pos, pos.z, true, false)
veh_spawn23 = vehicle.create_vehicle(veh_hash23, pos, pos.z, true, false)
veh_spawn24 = vehicle.create_vehicle(veh_hash24, pos, pos.z, true, false)
veh_spawn25 = vehicle.create_vehicle(veh_hash25, pos, pos.z, true, false)
v2_veh_spawn = vehicle.create_vehicle(veh_hash26, pos, pos.z, true, false)
v2_veh_spawn1 = vehicle.create_vehicle(veh_hash27, pos, pos.z, true, false)
v2_veh_spawn2 = vehicle.create_vehicle(veh_hash28, pos, pos.z, true, false)
v2_veh_spawn3 = vehicle.create_vehicle(veh_hash29, pos, pos.z, true, false)
v2_veh_spawn4 = vehicle.create_vehicle(veh_hash30, pos, pos.z, true, false)
v2_veh_spawn5 = vehicle.create_vehicle(veh_hash31, pos, pos.z, true, false)
v2_veh_spawn6 = vehicle.create_vehicle(veh_hash32, pos, pos.z, true, false)
v2_veh_spawn7 = vehicle.create_vehicle(veh_hash33, pos, pos.z, true, false)
v2_veh_spawn8 = vehicle.create_vehicle(veh_hash34, pos, pos.z, true, false)
v2_veh_spawn9 = vehicle.create_vehicle(veh_hash35, pos, pos.z, true, false)
v2_veh_spawn10 = vehicle.create_vehicle(veh_hash36, pos, pos.z, true, false)
v2_veh_spawn11 = vehicle.create_vehicle(veh_hash1, pos, pos.z, true, false)
v2_veh_spawn12 = vehicle.create_vehicle(veh_hash2, pos, pos.z, true, false)
v2_veh_spawn13 = vehicle.create_vehicle(veh_hash3, pos, pos.z, true, false)
v2_veh_spawn14 = vehicle.create_vehicle(veh_hash4, pos, pos.z, true, false)
v2_veh_spawn15 = vehicle.create_vehicle(veh_hash5, pos, pos.z, true, false)
v2_veh_spawn16 = vehicle.create_vehicle(veh_hash6, pos, pos.z, true, false)
v2_veh_spawn17 = vehicle.create_vehicle(veh_hash7, pos, pos.z, true, false)
v2_veh_spawn18 = vehicle.create_vehicle(veh_hash8, pos, pos.z, true, false)
v2_veh_spawn19 = vehicle.create_vehicle(veh_hash9, pos, pos.z, true, false)
v2_veh_spawn20 = vehicle.create_vehicle(veh_hash10, pos, pos.z, true, false)
v2_veh_spawn21 = vehicle.create_vehicle(veh_hash11, pos, pos.z, true, false)
v2_veh_spawn22 = vehicle.create_vehicle(veh_hash12, pos, pos.z, true, false)
v2_veh_spawn23 = vehicle.create_vehicle(veh_hash13, pos, pos.z, true, false)
v2_veh_spawn24 = vehicle.create_vehicle(veh_hash14, pos, pos.z, true, false)
v2_veh_spawn25 = vehicle.create_vehicle(veh_hash15, pos, pos.z, true, false)
v3_veh_spawn = vehicle.create_vehicle(veh_hash16, pos, pos.z, true, false)
v3_veh_spawn1 = vehicle.create_vehicle(veh_hash17, pos, pos.z, true, false)
v3_veh_spawn2 = vehicle.create_vehicle(veh_hash18, pos, pos.z, true, false)
v3_veh_spawn3 = vehicle.create_vehicle(veh_hash19, pos, pos.z, true, false)
v3_veh_spawn4 = vehicle.create_vehicle(veh_hash20, pos, pos.z, true, false)
v3_veh_spawn5 = vehicle.create_vehicle(veh_hash21, pos, pos.z, true, false)
v3_veh_spawn6 = vehicle.create_vehicle(veh_hash22, pos, pos.z, true, false)
v3_veh_spawn7 = vehicle.create_vehicle(veh_hash23, pos, pos.z, true, false)
v3_veh_spawn8 = vehicle.create_vehicle(veh_hash24, pos, pos.z, true, false)
v3_veh_spawn9 = vehicle.create_vehicle(veh_hash25, pos, pos.z, true, false)
v3_veh_spawn10 = vehicle.create_vehicle(veh_hash26, pos, pos.z, true, false)
v3_veh_spawn11 = vehicle.create_vehicle(veh_hash27, pos, pos.z, true, false)
v3_veh_spawn12 = vehicle.create_vehicle(veh_hash28, pos, pos.z, true, false)
v3_veh_spawn13 = vehicle.create_vehicle(veh_hash29, pos, pos.z, true, false)
v3_veh_spawn14 = vehicle.create_vehicle(veh_hash30, pos, pos.z, true, false)
v3_veh_spawn15 = vehicle.create_vehicle(veh_hash31, pos, pos.z, true, false)
v3_veh_spawn16 = vehicle.create_vehicle(veh_hash32, pos, pos.z, true, false)
v3_veh_spawn17 = vehicle.create_vehicle(veh_hash33, pos, pos.z, true, false)
v3_veh_spawn18 = vehicle.create_vehicle(veh_hash34, pos, pos.z, true, false)
v3_veh_spawn19 = vehicle.create_vehicle(veh_hash35, pos, pos.z, true, false)
v3_veh_spawn20 = vehicle.create_vehicle(veh_hash36, pos, pos.z, true, false)
v3_veh_spawn21 = vehicle.create_vehicle(veh_hash1, pos, pos.z, true, false)
v3_veh_spawn22 = vehicle.create_vehicle(veh_hash16, pos, pos.z, true, false)
v3_veh_spawn23 = vehicle.create_vehicle(veh_hash12, pos, pos.z, true, false)
v3_veh_spawn24 = vehicle.create_vehicle(veh_hash33, pos, pos.z, true, false)
v3_veh_spawn25 = vehicle.create_vehicle(veh_hash35, pos, pos.z, true, false)
entity.set_entity_god_mode(veh_spawn, true)
entity.set_entity_god_mode(veh_spawn1, true)
entity.set_entity_god_mode(veh_spawn2, true)
entity.set_entity_god_mode(veh_spawn3, true)
entity.set_entity_god_mode(veh_spawn4, true)
entity.set_entity_god_mode(veh_spawn5, true)
entity.set_entity_god_mode(veh_spawn6, true)
entity.set_entity_god_mode(veh_spawn7, true)
entity.set_entity_god_mode(veh_spawn8, true)
entity.set_entity_god_mode(veh_spawn9, true)
entity.set_entity_god_mode(veh_spawn10, true)
entity.set_entity_god_mode(veh_spawn11, true)
entity.set_entity_god_mode(veh_spawn12, true)
entity.set_entity_god_mode(veh_spawn13, true)
entity.set_entity_god_mode(veh_spawn14, true)
entity.set_entity_god_mode(veh_spawn15, true)
entity.set_entity_god_mode(veh_spawn16, true)
entity.set_entity_god_mode(veh_spawn17, true)
entity.set_entity_god_mode(veh_spawn18, true)
entity.set_entity_god_mode(veh_spawn19, true)
entity.set_entity_god_mode(veh_spawn20, true)
entity.set_entity_god_mode(veh_spawn21, true)
entity.set_entity_god_mode(veh_spawn22, true)
entity.set_entity_god_mode(veh_spawn23, true)
entity.set_entity_god_mode(veh_spawn24, true)
entity.set_entity_god_mode(veh_spawn25, true)
entity.set_entity_god_mode(v2_veh_spawn, true)
entity.set_entity_god_mode(v2_veh_spawn1, true)
entity.set_entity_god_mode(v2_veh_spawn2, true)
entity.set_entity_god_mode(v2_veh_spawn3, true)
entity.set_entity_god_mode(v2_veh_spawn4, true)
entity.set_entity_god_mode(v2_veh_spawn5, true)
entity.set_entity_god_mode(v2_veh_spawn6, true)
entity.set_entity_god_mode(v2_veh_spawn7, true)
entity.set_entity_god_mode(v2_veh_spawn8, true)
entity.set_entity_god_mode(v2_veh_spawn9, true)
entity.set_entity_god_mode(v2_veh_spawn10, true)
entity.set_entity_god_mode(v2_veh_spawn11, true)
entity.set_entity_god_mode(v2_veh_spawn12, true)
entity.set_entity_god_mode(v2_veh_spawn13, true)
entity.set_entity_god_mode(v2_veh_spawn14, true)
entity.set_entity_god_mode(v2_veh_spawn15, true)
entity.set_entity_god_mode(v2_veh_spawn16, true)
entity.set_entity_god_mode(v2_veh_spawn17, true)
entity.set_entity_god_mode(v2_veh_spawn18, true)
entity.set_entity_god_mode(v2_veh_spawn19, true)
entity.set_entity_god_mode(v2_veh_spawn20, true)
entity.set_entity_god_mode(v2_veh_spawn21, true)
entity.set_entity_god_mode(v2_veh_spawn22, true)
entity.set_entity_god_mode(v2_veh_spawn23, true)
entity.set_entity_god_mode(v2_veh_spawn24, true)
entity.set_entity_god_mode(v2_veh_spawn25, true)
entity.set_entity_god_mode(v3_veh_spawn, true)
entity.set_entity_god_mode(v3_veh_spawn1, true)
entity.set_entity_god_mode(v3_veh_spawn2, true)
entity.set_entity_god_mode(v3_veh_spawn3, true)
entity.set_entity_god_mode(v3_veh_spawn4, true)
entity.set_entity_god_mode(v3_veh_spawn5, true)
entity.set_entity_god_mode(v3_veh_spawn6, true)
entity.set_entity_god_mode(v3_veh_spawn7, true)
entity.set_entity_god_mode(v3_veh_spawn8, true)
entity.set_entity_god_mode(v3_veh_spawn9, true)
entity.set_entity_god_mode(v3_veh_spawn10, true)
entity.set_entity_god_mode(v3_veh_spawn11, true)
entity.set_entity_god_mode(v3_veh_spawn12, true)
entity.set_entity_god_mode(v3_veh_spawn13, true)
entity.set_entity_god_mode(v3_veh_spawn14, true)
entity.set_entity_god_mode(v3_veh_spawn15, true)
entity.set_entity_god_mode(v3_veh_spawn16, true)
entity.set_entity_god_mode(v3_veh_spawn17, true)
entity.set_entity_god_mode(v3_veh_spawn18, true)
entity.set_entity_god_mode(v3_veh_spawn19, true)
entity.set_entity_god_mode(v3_veh_spawn20, true)
entity.set_entity_god_mode(v3_veh_spawn21, true)
entity.set_entity_god_mode(v3_veh_spawn22, true)
entity.set_entity_god_mode(v3_veh_spawn23, true)
entity.set_entity_god_mode(v3_veh_spawn24, true)
entity.set_entity_god_mode(v3_veh_spawn25, true)
entity.set_entity_god_mode(veh_spawn, true)
entity.set_entity_god_mode(veh_spawn1, true)
entity.set_entity_god_mode(veh_spawn2, true)
entity.set_entity_god_mode(veh_spawn3, true)
entity.set_entity_god_mode(veh_spawn4, true)
entity.set_entity_god_mode(veh_spawn5, true)
entity.set_entity_god_mode(veh_spawn6, true)
entity.set_entity_god_mode(veh_spawn7, true)
entity.set_entity_god_mode(veh_spawn8, true)
entity.set_entity_god_mode(veh_spawn9, true)
entity.set_entity_god_mode(veh_spawn10, true)
entity.set_entity_god_mode(veh_spawn11, true)
entity.set_entity_god_mode(veh_spawn12, true)
entity.set_entity_god_mode(veh_spawn13, true)
entity.set_entity_god_mode(veh_spawn14, true)
entity.set_entity_god_mode(veh_spawn15, true)
entity.set_entity_god_mode(veh_spawn16, true)
entity.set_entity_god_mode(veh_spawn17, true)
entity.set_entity_god_mode(veh_spawn18, true)
entity.set_entity_god_mode(veh_spawn19, true)
entity.set_entity_god_mode(veh_spawn20, true)
entity.set_entity_god_mode(veh_spawn21, true)
entity.set_entity_god_mode(veh_spawn22, true)
entity.set_entity_god_mode(veh_spawn23, true)
entity.set_entity_god_mode(veh_spawn24, true)
entity.set_entity_god_mode(veh_spawn25, true)
entity.set_entity_god_mode(v2_veh_spawn, true)
entity.set_entity_god_mode(v2_veh_spawn1, true)
entity.set_entity_god_mode(v2_veh_spawn2, true)
entity.set_entity_god_mode(v2_veh_spawn3, true)
entity.set_entity_god_mode(v2_veh_spawn4, true)
entity.set_entity_god_mode(v2_veh_spawn5, true)
entity.set_entity_god_mode(v2_veh_spawn6, true)
entity.set_entity_god_mode(v2_veh_spawn7, true)
entity.set_entity_god_mode(v2_veh_spawn8, true)
entity.set_entity_god_mode(v2_veh_spawn9, true)
entity.set_entity_god_mode(v2_veh_spawn10, true)
entity.set_entity_god_mode(v2_veh_spawn11, true)
entity.set_entity_god_mode(v2_veh_spawn12, true)
entity.set_entity_god_mode(v2_veh_spawn13, true)
entity.set_entity_god_mode(v2_veh_spawn14, true)
entity.set_entity_god_mode(v2_veh_spawn15, true)
entity.set_entity_god_mode(v2_veh_spawn16, true)
entity.set_entity_god_mode(v2_veh_spawn17, true)
entity.set_entity_god_mode(v2_veh_spawn18, true)
entity.set_entity_god_mode(v2_veh_spawn19, true)
entity.set_entity_god_mode(v2_veh_spawn20, true)
entity.set_entity_god_mode(v2_veh_spawn21, true)
entity.set_entity_god_mode(v2_veh_spawn22, true)
entity.set_entity_god_mode(v2_veh_spawn23, true)
entity.set_entity_god_mode(v2_veh_spawn24, true)
entity.set_entity_god_mode(v2_veh_spawn25, true)
entity.set_entity_god_mode(v3_veh_spawn, true)
entity.set_entity_god_mode(v3_veh_spawn1, true)
entity.set_entity_god_mode(v3_veh_spawn2, true)
entity.set_entity_god_mode(v3_veh_spawn3, true)
entity.set_entity_god_mode(v3_veh_spawn4, true)
entity.set_entity_god_mode(v3_veh_spawn5, true)
entity.set_entity_god_mode(v3_veh_spawn6, true)
entity.set_entity_god_mode(v3_veh_spawn7, true)
entity.set_entity_god_mode(v3_veh_spawn8, true)
entity.set_entity_god_mode(v3_veh_spawn9, true)
entity.set_entity_god_mode(v3_veh_spawn10, true)
entity.set_entity_god_mode(v3_veh_spawn11, true)
entity.set_entity_god_mode(v3_veh_spawn12, true)
entity.set_entity_god_mode(v3_veh_spawn13, true)
entity.set_entity_god_mode(v3_veh_spawn14, true)
entity.set_entity_god_mode(v3_veh_spawn15, true)
entity.set_entity_god_mode(v3_veh_spawn16, true)
entity.set_entity_god_mode(v3_veh_spawn17, true)
entity.set_entity_god_mode(v3_veh_spawn18, true)
entity.set_entity_god_mode(v3_veh_spawn19, true)
entity.set_entity_god_mode(v3_veh_spawn20, true)
entity.set_entity_god_mode(v3_veh_spawn21, true)
entity.set_entity_god_mode(v3_veh_spawn22, true)
entity.set_entity_god_mode(v3_veh_spawn23, true)
entity.set_entity_god_mode(v3_veh_spawn24, true)
entity.set_entity_god_mode(v3_veh_spawn25, true)
entity.set_entity_god_mode(veh_spawn, true)
entity.set_entity_god_mode(veh_spawn1, true)
entity.set_entity_god_mode(veh_spawn2, true)
entity.set_entity_god_mode(veh_spawn3, true)
entity.set_entity_god_mode(veh_spawn4, true)
entity.set_entity_god_mode(veh_spawn5, true)
entity.set_entity_god_mode(veh_spawn6, true)
entity.set_entity_god_mode(veh_spawn7, true)
entity.set_entity_god_mode(veh_spawn8, true)
entity.set_entity_god_mode(veh_spawn9, true)
entity.set_entity_god_mode(veh_spawn10, true)
entity.set_entity_god_mode(veh_spawn11, true)
entity.set_entity_god_mode(veh_spawn12, true)
entity.set_entity_god_mode(veh_spawn13, true)
entity.set_entity_god_mode(veh_spawn14, true)
entity.set_entity_god_mode(veh_spawn15, true)
entity.set_entity_god_mode(veh_spawn16, true)
entity.set_entity_god_mode(veh_spawn17, true)
entity.set_entity_god_mode(veh_spawn18, true)
entity.set_entity_god_mode(veh_spawn19, true)
entity.set_entity_god_mode(veh_spawn20, true)
entity.set_entity_god_mode(veh_spawn21, true)
entity.set_entity_god_mode(veh_spawn22, true)
entity.set_entity_god_mode(veh_spawn23, true)
entity.set_entity_god_mode(veh_spawn24, true)
entity.set_entity_god_mode(veh_spawn25, true)
entity.set_entity_god_mode(v2_veh_spawn, true)
entity.set_entity_god_mode(v2_veh_spawn1, true)
entity.set_entity_god_mode(v2_veh_spawn2, true)
entity.set_entity_god_mode(v2_veh_spawn3, true)
entity.set_entity_god_mode(v2_veh_spawn4, true)
entity.set_entity_god_mode(v2_veh_spawn5, true)
entity.set_entity_god_mode(v2_veh_spawn6, true)
entity.set_entity_god_mode(v2_veh_spawn7, true)
entity.set_entity_god_mode(v2_veh_spawn8, true)
entity.set_entity_god_mode(v2_veh_spawn9, true)
entity.set_entity_god_mode(v2_veh_spawn10, true)
entity.set_entity_god_mode(v2_veh_spawn11, true)
entity.set_entity_god_mode(v2_veh_spawn12, true)
entity.set_entity_god_mode(v2_veh_spawn13, true)
entity.set_entity_god_mode(v2_veh_spawn14, true)
entity.set_entity_god_mode(v2_veh_spawn15, true)
entity.set_entity_god_mode(v2_veh_spawn16, true)
entity.set_entity_god_mode(v2_veh_spawn17, true)
entity.set_entity_god_mode(v2_veh_spawn18, true)
entity.set_entity_god_mode(v2_veh_spawn19, true)
entity.set_entity_god_mode(v2_veh_spawn20, true)
entity.set_entity_god_mode(v2_veh_spawn21, true)
entity.set_entity_god_mode(v2_veh_spawn22, true)
entity.set_entity_god_mode(v2_veh_spawn23, true)
entity.set_entity_god_mode(v2_veh_spawn24, true)
entity.set_entity_god_mode(v2_veh_spawn25, true)
entity.set_entity_god_mode(v3_veh_spawn, true)
entity.set_entity_god_mode(v3_veh_spawn1, true)
entity.set_entity_god_mode(v3_veh_spawn2, true)
entity.set_entity_god_mode(v3_veh_spawn3, true)
entity.set_entity_god_mode(v3_veh_spawn4, true)
entity.set_entity_god_mode(v3_veh_spawn5, true)
entity.set_entity_god_mode(v3_veh_spawn6, true)
entity.set_entity_god_mode(v3_veh_spawn7, true)
entity.set_entity_god_mode(v3_veh_spawn8, true)
entity.set_entity_god_mode(v3_veh_spawn9, true)
entity.set_entity_god_mode(v3_veh_spawn10, true)
entity.set_entity_god_mode(v3_veh_spawn11, true)
entity.set_entity_god_mode(v3_veh_spawn12, true)
entity.set_entity_god_mode(v3_veh_spawn13, true)
entity.set_entity_god_mode(v3_veh_spawn14, true)
entity.set_entity_god_mode(v3_veh_spawn15, true)
entity.set_entity_god_mode(v3_veh_spawn16, true)
entity.set_entity_god_mode(v3_veh_spawn17, true)
entity.set_entity_god_mode(v3_veh_spawn18, true)
entity.set_entity_god_mode(v3_veh_spawn19, true)
entity.set_entity_god_mode(v3_veh_spawn20, true)
entity.set_entity_god_mode(v3_veh_spawn21, true)
entity.set_entity_god_mode(v3_veh_spawn22, true)
entity.set_entity_god_mode(v3_veh_spawn23, true)
entity.set_entity_god_mode(v3_veh_spawn24, true)
entity.set_entity_god_mode(v3_veh_spawn25, true)
entity.set_entity_god_mode(veh_spawn, true)
entity.set_entity_god_mode(veh_spawn1, true)
entity.set_entity_god_mode(veh_spawn2, true)
entity.set_entity_god_mode(veh_spawn3, true)
entity.set_entity_god_mode(veh_spawn4, true)
entity.set_entity_god_mode(veh_spawn5, true)
entity.set_entity_god_mode(veh_spawn6, true)
entity.set_entity_god_mode(veh_spawn7, true)
entity.set_entity_god_mode(veh_spawn8, true)
entity.set_entity_god_mode(veh_spawn9, true)
entity.set_entity_god_mode(veh_spawn10, true)
entity.set_entity_god_mode(veh_spawn11, true)
entity.set_entity_god_mode(veh_spawn12, true)
entity.set_entity_god_mode(veh_spawn13, true)
entity.set_entity_god_mode(veh_spawn14, true)
entity.set_entity_god_mode(veh_spawn15, true)
entity.set_entity_god_mode(veh_spawn16, true)
entity.set_entity_god_mode(veh_spawn17, true)
entity.set_entity_god_mode(veh_spawn18, true)
entity.set_entity_god_mode(veh_spawn19, true)
entity.set_entity_god_mode(veh_spawn20, true)
entity.set_entity_god_mode(veh_spawn21, true)
entity.set_entity_god_mode(veh_spawn22, true)
entity.set_entity_god_mode(veh_spawn23, true)
entity.set_entity_god_mode(veh_spawn24, true)
entity.set_entity_god_mode(veh_spawn25, true)
entity.set_entity_god_mode(v2_veh_spawn, true)
entity.set_entity_god_mode(v2_veh_spawn1, true)
entity.set_entity_god_mode(v2_veh_spawn2, true)
entity.set_entity_god_mode(v2_veh_spawn3, true)
entity.set_entity_god_mode(v2_veh_spawn4, true)
entity.set_entity_god_mode(v2_veh_spawn5, true)
entity.set_entity_god_mode(v2_veh_spawn6, true)
entity.set_entity_god_mode(v2_veh_spawn7, true)
entity.set_entity_god_mode(v2_veh_spawn8, true)
entity.set_entity_god_mode(v2_veh_spawn9, true)
entity.set_entity_god_mode(v2_veh_spawn10, true)
entity.set_entity_god_mode(v2_veh_spawn11, true)
entity.set_entity_god_mode(v2_veh_spawn12, true)
entity.set_entity_god_mode(v2_veh_spawn13, true)
entity.set_entity_god_mode(v2_veh_spawn14, true)
entity.set_entity_god_mode(v2_veh_spawn15, true)
entity.set_entity_god_mode(v2_veh_spawn16, true)
entity.set_entity_god_mode(v2_veh_spawn17, true)
entity.set_entity_god_mode(v2_veh_spawn18, true)
entity.set_entity_god_mode(v2_veh_spawn19, true)
entity.set_entity_god_mode(v2_veh_spawn20, true)
entity.set_entity_god_mode(v2_veh_spawn21, true)
entity.set_entity_god_mode(v2_veh_spawn22, true)
entity.set_entity_god_mode(v2_veh_spawn23, true)
entity.set_entity_god_mode(v2_veh_spawn24, true)
entity.set_entity_god_mode(v2_veh_spawn25, true)
entity.set_entity_god_mode(v3_veh_spawn, true)
entity.set_entity_god_mode(v3_veh_spawn1, true)
entity.set_entity_god_mode(v3_veh_spawn2, true)
entity.set_entity_god_mode(v3_veh_spawn3, true)
entity.set_entity_god_mode(v3_veh_spawn4, true)
entity.set_entity_god_mode(v3_veh_spawn5, true)
entity.set_entity_god_mode(v3_veh_spawn6, true)
entity.set_entity_god_mode(v3_veh_spawn7, true)
entity.set_entity_god_mode(v3_veh_spawn8, true)
entity.set_entity_god_mode(v3_veh_spawn9, true)
entity.set_entity_god_mode(v3_veh_spawn10, true)
entity.set_entity_god_mode(v3_veh_spawn11, true)
entity.set_entity_god_mode(v3_veh_spawn12, true)
entity.set_entity_god_mode(v3_veh_spawn13, true)
entity.set_entity_god_mode(v3_veh_spawn14, true)
entity.set_entity_god_mode(v3_veh_spawn15, true)
entity.set_entity_god_mode(v3_veh_spawn16, true)
entity.set_entity_god_mode(v3_veh_spawn17, true)
entity.set_entity_god_mode(v3_veh_spawn18, true)
entity.set_entity_god_mode(v3_veh_spawn19, true)
entity.set_entity_god_mode(v3_veh_spawn20, true)
entity.set_entity_god_mode(v3_veh_spawn21, true)
entity.set_entity_god_mode(v3_veh_spawn22, true)
entity.set_entity_god_mode(v3_veh_spawn23, true)
entity.set_entity_god_mode(v3_veh_spawn24, true)
entity.set_entity_god_mode(v3_veh_spawn25, true)
entity.set_entity_visible(veh_spawn, false)
entity.set_entity_visible(veh_spawn1, false)
entity.set_entity_visible(veh_spawn2, false)
entity.set_entity_visible(veh_spawn3, false)
entity.set_entity_visible(veh_spawn4, false)
entity.set_entity_visible(veh_spawn5, false)
entity.set_entity_visible(veh_spawn6, false)
entity.set_entity_visible(veh_spawn7, false)
entity.set_entity_visible(veh_spawn8, false)
entity.set_entity_visible(veh_spawn9, false)
entity.set_entity_visible(veh_spawn10, false)
entity.set_entity_visible(veh_spawn11, false)
entity.set_entity_visible(veh_spawn12, false)
entity.set_entity_visible(veh_spawn13, false)
entity.set_entity_visible(veh_spawn14, false)
entity.set_entity_visible(veh_spawn15, false)
entity.set_entity_visible(veh_spawn16, false)
entity.set_entity_visible(veh_spawn17, false)
entity.set_entity_visible(veh_spawn18, false)
entity.set_entity_visible(veh_spawn19, false)
entity.set_entity_visible(veh_spawn20, false)
entity.set_entity_visible(veh_spawn21, false)
entity.set_entity_visible(veh_spawn22, false)
entity.set_entity_visible(veh_spawn23, false)
entity.set_entity_visible(veh_spawn24, false)
entity.set_entity_visible(veh_spawn25, false)
entity.set_entity_visible(v2_veh_spawn, false)
entity.set_entity_visible(v2_veh_spawn1, false)
entity.set_entity_visible(v2_veh_spawn2, false)
entity.set_entity_visible(v2_veh_spawn3, false)
entity.set_entity_visible(v2_veh_spawn4, false)
entity.set_entity_visible(v2_veh_spawn5, false)
entity.set_entity_visible(v2_veh_spawn6, false)
entity.set_entity_visible(v2_veh_spawn7, false)
entity.set_entity_visible(v2_veh_spawn8, false)
entity.set_entity_visible(v2_veh_spawn9, false)
entity.set_entity_visible(v2_veh_spawn10, false)
entity.set_entity_visible(v2_veh_spawn11, false)
entity.set_entity_visible(v2_veh_spawn12, false)
entity.set_entity_visible(v2_veh_spawn13, false)
entity.set_entity_visible(v2_veh_spawn14, false)
entity.set_entity_visible(v2_veh_spawn15, false)
entity.set_entity_visible(v2_veh_spawn16, false)
entity.set_entity_visible(v2_veh_spawn17, false)
entity.set_entity_visible(v2_veh_spawn18, false)
entity.set_entity_visible(v2_veh_spawn19, false)
entity.set_entity_visible(v2_veh_spawn20, false)
entity.set_entity_visible(v2_veh_spawn21, false)
entity.set_entity_visible(v2_veh_spawn22, false)
entity.set_entity_visible(v2_veh_spawn23, false)
entity.set_entity_visible(v2_veh_spawn24, false)
entity.set_entity_visible(v2_veh_spawn25, false)
entity.set_entity_visible(v3_veh_spawn, false)
entity.set_entity_visible(v3_veh_spawn1, false)
entity.set_entity_visible(v3_veh_spawn2, false)
entity.set_entity_visible(v3_veh_spawn3, false)
entity.set_entity_visible(v3_veh_spawn4, false)
entity.set_entity_visible(v3_veh_spawn5, false)
entity.set_entity_visible(v3_veh_spawn6, false)
entity.set_entity_visible(v3_veh_spawn7, false)
entity.set_entity_visible(v3_veh_spawn8, false)
entity.set_entity_visible(v3_veh_spawn9, false)
entity.set_entity_visible(v3_veh_spawn10, false)
entity.set_entity_visible(v3_veh_spawn11, false)
entity.set_entity_visible(v3_veh_spawn12, false)
entity.set_entity_visible(v3_veh_spawn13, false)
entity.set_entity_visible(v3_veh_spawn14, false)
entity.set_entity_visible(v3_veh_spawn15, false)
entity.set_entity_visible(v3_veh_spawn16, false)
entity.set_entity_visible(v3_veh_spawn17, false)
entity.set_entity_visible(v3_veh_spawn18, false)
entity.set_entity_visible(v3_veh_spawn19, false)
entity.set_entity_visible(v3_veh_spawn20, false)
entity.set_entity_visible(v3_veh_spawn21, false)
entity.set_entity_visible(v3_veh_spawn22, false)
entity.set_entity_visible(v3_veh_spawn23, false)
entity.set_entity_visible(v3_veh_spawn24, false)
entity.set_entity_visible(v3_veh_spawn25, false)
entity.set_entity_visible(veh_spawn, false)
entity.set_entity_visible(veh_spawn1, false)
entity.set_entity_visible(veh_spawn2, false)
entity.set_entity_visible(veh_spawn3, false)
entity.set_entity_visible(veh_spawn4, false)
entity.set_entity_visible(veh_spawn5, false)
entity.set_entity_visible(veh_spawn6, false)
entity.set_entity_visible(veh_spawn7, false)
entity.set_entity_visible(veh_spawn8, false)
entity.set_entity_visible(veh_spawn9, false)
entity.set_entity_visible(veh_spawn10, false)
entity.set_entity_visible(veh_spawn11, false)
entity.set_entity_visible(veh_spawn12, false)
entity.set_entity_visible(veh_spawn13, false)
entity.set_entity_visible(veh_spawn14, false)
entity.set_entity_visible(veh_spawn15, false)
entity.set_entity_visible(veh_spawn16, false)
entity.set_entity_visible(veh_spawn17, false)
entity.set_entity_visible(veh_spawn18, false)
entity.set_entity_visible(veh_spawn19, false)
entity.set_entity_visible(veh_spawn20, false)
entity.set_entity_visible(veh_spawn21, false)
entity.set_entity_visible(veh_spawn22, false)
entity.set_entity_visible(veh_spawn23, false)
entity.set_entity_visible(veh_spawn24, false)
entity.set_entity_visible(veh_spawn25, false)
entity.set_entity_visible(v2_veh_spawn, false)
entity.set_entity_visible(v2_veh_spawn1, false)
entity.set_entity_visible(v2_veh_spawn2, false)
entity.set_entity_visible(v2_veh_spawn3, false)
entity.set_entity_visible(v2_veh_spawn4, false)
entity.set_entity_visible(v2_veh_spawn5, false)
entity.set_entity_visible(v2_veh_spawn6, false)
entity.set_entity_visible(v2_veh_spawn7, false)
entity.set_entity_visible(v2_veh_spawn8, false)
entity.set_entity_visible(v2_veh_spawn9, false)
entity.set_entity_visible(v2_veh_spawn10, false)
entity.set_entity_visible(v2_veh_spawn11, false)
entity.set_entity_visible(v2_veh_spawn12, false)
entity.set_entity_visible(v2_veh_spawn13, false)
entity.set_entity_visible(v2_veh_spawn14, false)
entity.set_entity_visible(v2_veh_spawn15, false)
entity.set_entity_visible(v2_veh_spawn16, false)
entity.set_entity_visible(v2_veh_spawn17, false)
entity.set_entity_visible(v2_veh_spawn18, false)
entity.set_entity_visible(v2_veh_spawn19, false)
entity.set_entity_visible(v2_veh_spawn20, false)
entity.set_entity_visible(v2_veh_spawn21, false)
entity.set_entity_visible(v2_veh_spawn22, false)
entity.set_entity_visible(v2_veh_spawn23, false)
entity.set_entity_visible(v2_veh_spawn24, false)
entity.set_entity_visible(v2_veh_spawn25, false)
entity.set_entity_visible(v3_veh_spawn, false)
entity.set_entity_visible(v3_veh_spawn1, false)
entity.set_entity_visible(v3_veh_spawn2, false)
entity.set_entity_visible(v3_veh_spawn3, false)
entity.set_entity_visible(v3_veh_spawn4, false)
entity.set_entity_visible(v3_veh_spawn5, false)
entity.set_entity_visible(v3_veh_spawn6, false)
entity.set_entity_visible(v3_veh_spawn7, false)
entity.set_entity_visible(v3_veh_spawn8, false)
entity.set_entity_visible(v3_veh_spawn9, false)
entity.set_entity_visible(v3_veh_spawn10, false)
entity.set_entity_visible(v3_veh_spawn11, false)
entity.set_entity_visible(v3_veh_spawn12, false)
entity.set_entity_visible(v3_veh_spawn13, false)
entity.set_entity_visible(v3_veh_spawn14, false)
entity.set_entity_visible(v3_veh_spawn15, false)
entity.set_entity_visible(v3_veh_spawn16, false)
entity.set_entity_visible(v3_veh_spawn17, false)
entity.set_entity_visible(v3_veh_spawn18, false)
entity.set_entity_visible(v3_veh_spawn19, false)
entity.set_entity_visible(v3_veh_spawn20, false)
entity.set_entity_visible(v3_veh_spawn21, false)
entity.set_entity_visible(v3_veh_spawn22, false)
entity.set_entity_visible(v3_veh_spawn23, false)
entity.set_entity_visible(v3_veh_spawn24, false)
entity.set_entity_visible(v3_veh_spawn25, false)
entity.set_entity_visible(veh_spawn, false)
entity.set_entity_visible(veh_spawn1, false)
entity.set_entity_visible(veh_spawn2, false)
entity.set_entity_visible(veh_spawn3, false)
entity.set_entity_visible(veh_spawn4, false)
entity.set_entity_visible(veh_spawn5, false)
entity.set_entity_visible(veh_spawn6, false)
entity.set_entity_visible(veh_spawn7, false)
entity.set_entity_visible(veh_spawn8, false)
entity.set_entity_visible(veh_spawn9, false)
entity.set_entity_visible(veh_spawn10, false)
entity.set_entity_visible(veh_spawn11, false)
entity.set_entity_visible(veh_spawn12, false)
entity.set_entity_visible(veh_spawn13, false)
entity.set_entity_visible(veh_spawn14, false)
entity.set_entity_visible(veh_spawn15, false)
entity.set_entity_visible(veh_spawn16, false)
entity.set_entity_visible(veh_spawn17, false)
entity.set_entity_visible(veh_spawn18, false)
entity.set_entity_visible(veh_spawn19, false)
entity.set_entity_visible(veh_spawn20, false)
entity.set_entity_visible(veh_spawn21, false)
entity.set_entity_visible(veh_spawn22, false)
entity.set_entity_visible(veh_spawn23, false)
entity.set_entity_visible(veh_spawn24, false)
entity.set_entity_visible(veh_spawn25, false)
entity.set_entity_visible(v2_veh_spawn, false)
entity.set_entity_visible(v2_veh_spawn1, false)
entity.set_entity_visible(v2_veh_spawn2, false)
entity.set_entity_visible(v2_veh_spawn3, false)
entity.set_entity_visible(v2_veh_spawn4, false)
entity.set_entity_visible(v2_veh_spawn5, false)
entity.set_entity_visible(v2_veh_spawn6, false)
entity.set_entity_visible(v2_veh_spawn7, false)
entity.set_entity_visible(v2_veh_spawn8, false)
entity.set_entity_visible(v2_veh_spawn9, false)
entity.set_entity_visible(v2_veh_spawn10, false)
entity.set_entity_visible(v2_veh_spawn11, false)
entity.set_entity_visible(v2_veh_spawn12, false)
entity.set_entity_visible(v2_veh_spawn13, false)
entity.set_entity_visible(v2_veh_spawn14, false)
entity.set_entity_visible(v2_veh_spawn15, false)
entity.set_entity_visible(v2_veh_spawn16, false)
entity.set_entity_visible(v2_veh_spawn17, false)
entity.set_entity_visible(v2_veh_spawn18, false)
entity.set_entity_visible(v2_veh_spawn19, false)
entity.set_entity_visible(v2_veh_spawn20, false)
entity.set_entity_visible(v2_veh_spawn21, false)
entity.set_entity_visible(v2_veh_spawn22, false)
entity.set_entity_visible(v2_veh_spawn23, false)
entity.set_entity_visible(v2_veh_spawn24, false)
entity.set_entity_visible(v2_veh_spawn25, false)
entity.set_entity_visible(v3_veh_spawn, false)
entity.set_entity_visible(v3_veh_spawn1, false)
entity.set_entity_visible(v3_veh_spawn2, false)
entity.set_entity_visible(v3_veh_spawn3, false)
entity.set_entity_visible(v3_veh_spawn4, false)
entity.set_entity_visible(v3_veh_spawn5, false)
entity.set_entity_visible(v3_veh_spawn6, false)
entity.set_entity_visible(v3_veh_spawn7, false)
entity.set_entity_visible(v3_veh_spawn8, false)
entity.set_entity_visible(v3_veh_spawn9, false)
entity.set_entity_visible(v3_veh_spawn10, false)
entity.set_entity_visible(v3_veh_spawn11, false)
entity.set_entity_visible(v3_veh_spawn12, false)
entity.set_entity_visible(v3_veh_spawn13, false)
entity.set_entity_visible(v3_veh_spawn14, false)
entity.set_entity_visible(v3_veh_spawn15, false)
entity.set_entity_visible(v3_veh_spawn16, false)
entity.set_entity_visible(v3_veh_spawn17, false)
entity.set_entity_visible(v3_veh_spawn18, false)
entity.set_entity_visible(v3_veh_spawn19, false)
entity.set_entity_visible(v3_veh_spawn20, false)
entity.set_entity_visible(v3_veh_spawn21, false)
entity.set_entity_visible(v3_veh_spawn22, false)
entity.set_entity_visible(v3_veh_spawn23, false)
entity.set_entity_visible(v3_veh_spawn24, false)
entity.set_entity_visible(v3_veh_spawn25, false)
entity.set_entity_visible(veh_spawn, false)
entity.set_entity_visible(veh_spawn1, false)
entity.set_entity_visible(veh_spawn2, false)
entity.set_entity_visible(veh_spawn3, false)
entity.set_entity_visible(veh_spawn4, false)
entity.set_entity_visible(veh_spawn5, false)
entity.set_entity_visible(veh_spawn6, false)
entity.set_entity_visible(veh_spawn7, false)
entity.set_entity_visible(veh_spawn8, false)
entity.set_entity_visible(veh_spawn9, false)
entity.set_entity_visible(veh_spawn10, false)
entity.set_entity_visible(veh_spawn11, false)
entity.set_entity_visible(veh_spawn12, false)
entity.set_entity_visible(veh_spawn13, false)
entity.set_entity_visible(veh_spawn14, false)
entity.set_entity_visible(veh_spawn15, false)
entity.set_entity_visible(veh_spawn16, false)
entity.set_entity_visible(veh_spawn17, false)
entity.set_entity_visible(veh_spawn18, false)
entity.set_entity_visible(veh_spawn19, false)
entity.set_entity_visible(veh_spawn20, false)
entity.set_entity_visible(veh_spawn21, false)
entity.set_entity_visible(veh_spawn22, false)
entity.set_entity_visible(veh_spawn23, false)
entity.set_entity_visible(veh_spawn24, false)
entity.set_entity_visible(veh_spawn25, false)
entity.set_entity_visible(v2_veh_spawn, false)
entity.set_entity_visible(v2_veh_spawn1, false)
entity.set_entity_visible(v2_veh_spawn2, false)
entity.set_entity_visible(v2_veh_spawn3, false)
entity.set_entity_visible(v2_veh_spawn4, false)
entity.set_entity_visible(v2_veh_spawn5, false)
entity.set_entity_visible(v2_veh_spawn6, false)
entity.set_entity_visible(v2_veh_spawn7, false)
entity.set_entity_visible(v2_veh_spawn8, false)
entity.set_entity_visible(v2_veh_spawn9, false)
entity.set_entity_visible(v2_veh_spawn10, false)
entity.set_entity_visible(v2_veh_spawn11, false)
entity.set_entity_visible(v2_veh_spawn12, false)
entity.set_entity_visible(v2_veh_spawn13, false)
entity.set_entity_visible(v2_veh_spawn14, false)
entity.set_entity_visible(v2_veh_spawn15, false)
entity.set_entity_visible(v2_veh_spawn16, false)
entity.set_entity_visible(v2_veh_spawn17, false)
entity.set_entity_visible(v2_veh_spawn18, false)
entity.set_entity_visible(v2_veh_spawn19, false)
entity.set_entity_visible(v2_veh_spawn20, false)
entity.set_entity_visible(v2_veh_spawn21, false)
entity.set_entity_visible(v2_veh_spawn22, false)
entity.set_entity_visible(v2_veh_spawn23, false)
entity.set_entity_visible(v2_veh_spawn24, false)
entity.set_entity_visible(v2_veh_spawn25, false)
entity.set_entity_visible(v3_veh_spawn, false)
entity.set_entity_visible(v3_veh_spawn1, false)
entity.set_entity_visible(v3_veh_spawn2, false)
entity.set_entity_visible(v3_veh_spawn3, false)
entity.set_entity_visible(v3_veh_spawn4, false)
entity.set_entity_visible(v3_veh_spawn5, false)
entity.set_entity_visible(v3_veh_spawn6, false)
entity.set_entity_visible(v3_veh_spawn7, false)
entity.set_entity_visible(v3_veh_spawn8, false)
entity.set_entity_visible(v3_veh_spawn9, false)
entity.set_entity_visible(v3_veh_spawn10, false)
entity.set_entity_visible(v3_veh_spawn11, false)
entity.set_entity_visible(v3_veh_spawn12, false)
entity.set_entity_visible(v3_veh_spawn13, false)
entity.set_entity_visible(v3_veh_spawn14, false)
entity.set_entity_visible(v3_veh_spawn15, false)
entity.set_entity_visible(v3_veh_spawn16, false)
entity.set_entity_visible(v3_veh_spawn17, false)
entity.set_entity_visible(v3_veh_spawn18, false)
entity.set_entity_visible(v3_veh_spawn19, false)
entity.set_entity_visible(v3_veh_spawn20, false)
entity.set_entity_visible(v3_veh_spawn21, false)
entity.set_entity_visible(v3_veh_spawn22, false)
entity.set_entity_visible(v3_veh_spawn23, false)
entity.set_entity_visible(v3_veh_spawn24, false)
entity.set_entity_visible(v3_veh_spawn25, false)
system.wait(1000)

entity.delete_entity(veh_spawn)
entity.delete_entity(veh_spawn1)
entity.delete_entity(veh_spawn2)
entity.delete_entity(veh_spawn3)
entity.delete_entity(veh_spawn4)
entity.delete_entity(veh_spawn5)
entity.delete_entity(veh_spawn6)
entity.delete_entity(veh_spawn7)
entity.delete_entity(veh_spawn8)
entity.delete_entity(veh_spawn9)
entity.delete_entity(veh_spawn10)
entity.delete_entity(veh_spawn11)
entity.delete_entity(veh_spawn12)
entity.delete_entity(veh_spawn13)
entity.delete_entity(veh_spawn14)
entity.delete_entity(veh_spawn15)
entity.delete_entity(veh_spawn16)
entity.delete_entity(veh_spawn17)
entity.delete_entity(veh_spawn18)
entity.delete_entity(veh_spawn19)
entity.delete_entity(veh_spawn20)
		  entity.delete_entity(veh_spawn21)
		  entity.delete_entity(veh_spawn22)
		  entity.delete_entity(veh_spawn23)
		  entity.delete_entity(veh_spawn24)
		  entity.delete_entity(veh_spawn25)
		  entity.delete_entity(v2_veh_spawn)
entity.delete_entity(v2_veh_spawn1)
entity.delete_entity(v2_veh_spawn2)
entity.delete_entity(v2_veh_spawn3)
entity.delete_entity(v2_veh_spawn4)
entity.delete_entity(v2_veh_spawn5)
entity.delete_entity(v2_veh_spawn6)
entity.delete_entity(v2_veh_spawn7)
entity.delete_entity(v2_veh_spawn8)
entity.delete_entity(v2_veh_spawn9)
entity.delete_entity(v2_veh_spawn10)
entity.delete_entity(v2_veh_spawn11)
entity.delete_entity(v2_veh_spawn12)
entity.delete_entity(v2_veh_spawn13)
entity.delete_entity(v2_veh_spawn14)
entity.delete_entity(v2_veh_spawn15)
entity.delete_entity(v2_veh_spawn16)
entity.delete_entity(v2_veh_spawn17)
entity.delete_entity(v2_veh_spawn18)
entity.delete_entity(v2_veh_spawn19)
entity.delete_entity(v2_veh_spawn20)
		  entity.delete_entity(v2_veh_spawn21)
		  entity.delete_entity(v2_veh_spawn22)
		  entity.delete_entity(v2_veh_spawn23)
		  entity.delete_entity(v2_veh_spawn24)
		  entity.delete_entity(v2_veh_spawn25)
		  entity.delete_entity(v3_veh_spawn)
entity.delete_entity(v3_veh_spawn1)
entity.delete_entity(v3_veh_spawn2)
entity.delete_entity(v3_veh_spawn3)
entity.delete_entity(v3_veh_spawn4)
entity.delete_entity(v3_veh_spawn5)
entity.delete_entity(v3_veh_spawn6)
entity.delete_entity(v3_veh_spawn7)
entity.delete_entity(v3_veh_spawn8)
entity.delete_entity(v3_veh_spawn9)
entity.delete_entity(v3_veh_spawn10)
entity.delete_entity(v3_veh_spawn11)
entity.delete_entity(v3_veh_spawn12)
entity.delete_entity(v3_veh_spawn13)
entity.delete_entity(v3_veh_spawn14)
entity.delete_entity(v3_veh_spawn15)
entity.delete_entity(v3_veh_spawn16)
entity.delete_entity(v3_veh_spawn17)
entity.delete_entity(v3_veh_spawn18)
entity.delete_entity(v3_veh_spawn19)
entity.delete_entity(v3_veh_spawn20)
entity.delete_entity(v3_veh_spawn21)
entity.delete_entity(v3_veh_spawn22)
entity.delete_entity(v3_veh_spawn23)
entity.delete_entity(v3_veh_spawn24)
entity.delete_entity(v3_veh_spawn25)


		  streaming.set_model_as_no_longer_needed(veh_hash)
		  streaming.set_model_as_no_longer_needed(veh_hash1)
		  streaming.set_model_as_no_longer_needed(veh_hash2)
		  streaming.set_model_as_no_longer_needed(veh_hash3)
		  streaming.set_model_as_no_longer_needed(veh_hash4)
		  streaming.set_model_as_no_longer_needed(veh_hash5)
		  streaming.set_model_as_no_longer_needed(veh_hash6)
		  streaming.set_model_as_no_longer_needed(veh_hash7)
		  streaming.set_model_as_no_longer_needed(veh_hash8)
		  streaming.set_model_as_no_longer_needed(veh_hash9)
		  streaming.set_model_as_no_longer_needed(veh_hash10)
		  streaming.set_model_as_no_longer_needed(veh_hash11)
		  streaming.set_model_as_no_longer_needed(veh_hash12)
		  streaming.set_model_as_no_longer_needed(veh_hash13)
		  streaming.set_model_as_no_longer_needed(veh_hash14)
		  streaming.set_model_as_no_longer_needed(veh_hash15)
		  streaming.set_model_as_no_longer_needed(veh_hash16)
		  streaming.set_model_as_no_longer_needed(veh_hash17)
		  streaming.set_model_as_no_longer_needed(veh_hash18)
		  streaming.set_model_as_no_longer_needed(veh_hash19)
		  streaming.set_model_as_no_longer_needed(veh_hash20)
		  streaming.set_model_as_no_longer_needed(veh_hash21)
		  streaming.set_model_as_no_longer_needed(veh_hash22)
		  streaming.set_model_as_no_longer_needed(veh_hash23)
		  streaming.set_model_as_no_longer_needed(veh_hash24)
		  streaming.set_model_as_no_longer_needed(veh_hash25)
		  streaming.set_model_as_no_longer_needed(veh_hash26)
		  streaming.set_model_as_no_longer_needed(veh_hash27)
		  streaming.set_model_as_no_longer_needed(veh_hash28)
		  streaming.set_model_as_no_longer_needed(veh_hash29)
		  streaming.set_model_as_no_longer_needed(veh_hash30)
		  streaming.set_model_as_no_longer_needed(veh_hash31)
		  streaming.set_model_as_no_longer_needed(veh_hash32)
		  streaming.set_model_as_no_longer_needed(veh_hash33)
		  streaming.set_model_as_no_longer_needed(veh_hash34)
		  streaming.set_model_as_no_longer_needed(veh_hash35)
		  streaming.set_model_as_no_longer_needed(veh_hash36)
        end
        return HANDLER_CONTINUE
        end)


menu.add_player_feature("Railgun kill loop", "toggle", popt.loops, function(feat, pid)
    while feat.on do
      system.wait(0)
      local pos = v3()
      pos = player.get_player_coords(pid)
      pos.z = pos.z + 65.0
      gameplay.shoot_single_bullet_between_coords(pos, player.get_player_coords(pid) + v3(0, 0, 1), 10000.00, 0x6D544C99, 0, true, false, 10000.0)
    end
end)


menu.add_player_feature("Burn The Target", "action", popt.attach, function(playerfeat, pid)

    local playerped3 = player.get_player_ped(pid)
    local pos = v3()
    attach_object1132 = object.create_object(-1065766299, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)
end)

menu.add_player_feature("Conehead", "action", popt.attach, function(playerfeat, pid)

    local playerped3 = player.get_player_ped(pid)    
    local pos = v3()
    pos.z = pos.z + 0.50
    attach_object1132 = object.create_object(-1059647297, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)
end)

menu.add_player_feature("Trashman", "action", popt.attach, function(playerfeat, pid)
    

    local playerped3 = player.get_player_ped(pid)
    local pos = v3()
    pos.z = pos.z + 0.10
    attach_object1132 = object.create_object(1143474856, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)

    local pos1 = player.get_player_coords(pid)
    pos1.z = pos1.z + 0.10     
    local cageobjecthash = gameplay.get_hash_key("prop_ld_rub_binbag_01") 
    local cageobject = object.create_object(cageobjecthash, pos1, true, false)
end)


menu.add_player_feature("Cactus Jack", "action", popt.attach, function(playerfeat, pid)
	local playerped3 = player.get_player_ped(pid)
    local pos = v3()
    pos.z = pos.z -0.10
    attach_object1132 = object.create_object(-194496699, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)
end)

menu.add_player_feature("Hyrdrant Man", "action", popt.attach, function(playerfeat, pid)
	local playerped3 = player.get_player_ped(pid)
    local pos = v3()
    pos.z = pos.z + 0.10
    attach_object1132 = object.create_object(200846641, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)
end)

menu.add_player_feature("Gas Pump Man", "action", popt.attach, function(playerfeat, pid)
	local playerped3 = player.get_player_ped(pid)
    local pos = v3()
    pos.z = pos.z - 0.50
    attach_object1132 = object.create_object(-2007231801, pos, true, false)
    entity.attach_entity_to_entity(attach_object1132, playerped3, 0, pos, pos, true, true, false, 0, false)
end)

menu.add_player_feature("Safe Space(anti-crash-cam)", "toggle", 0, function(feat)
    location = player.get_player_coords(player.player_id()) --save location
    menu.notify("Here is safe space!", "", 1, 190)
    entity.set_entity_coords_no_offset(player.get_player_ped(player.player_id()), v3(-75, -818, 326)) --mazebank
    system.yield(10)
    while feat.on do
      entity.set_entity_coords_no_offset(player.get_player_ped(player.player_id()), v3(-8292.664, -4596.8257, 14358.0))--safe space
      system.yield(1000)
    end
    if feat.on == false then
      menu.notify("Wait a sec", "", 2, 190)
    end
    system.yield(10)
    entity.set_entity_coords_no_offset(player.get_player_ped(player.player_id()), location)
  end)

  
menu.add_feature("Undetected OTR", "toggle", opt.opption, function(feat)
    if feat.on then
		ped.set_ped_max_health(pedLocals,  0)
	end
	return HANDLER_CONTINUE
end)

menu.add_feature("Health Mod god mode", "toggle", opt.opption, function(feat)
    if feat.on then
        ped.set_ped_max_health(pedLocals, 1000000)
		ped.set_ped_health(pedLocals,  1000000)
    end
    return HANDLER_CONTINUE
end)